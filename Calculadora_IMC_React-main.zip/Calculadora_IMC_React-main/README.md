# Calculadora de IMC 

Calculadora de IMC feita com React + Typescript

Projeto desenvolvido durante o curso [B7Web](https://b7web.com.br)

### Instalação
- `npm install`

### Para rodar
- `npm start`